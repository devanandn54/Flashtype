import logo from './logo.svg';
import './App.css';
import Navbar from './Navbar';
import Landing from './Landing';
import Footer from './Footer';
import Challenge from './Challenge';
import { useEffect, useState } from 'react';


let totaltime = 10;
const url="http://metaphorpsum.com/paragraphs/1/9";
function App() {
const [selectedParagraph, setselectedParagraph] = useState("hello wold")
const [timerstarted, settimerstarted] = useState(false)
let [timeRemaining, settimeRemaining] = useState(totaltime)
const [Words,setWords] = useState(0)
const [characters,setCharacters] = useState(0)
const [Wpm,setWpm] = useState(0);
const [testInfo, settestInfo]=useState([])




useEffect(()=>{
  fetch(url).then((resp) => resp.text()).then((data)=>{
    
    const paragraphArray=data.split("")
 const testInfo= paragraphArray.map((selectedLetter) =>{


    return{
      testLetter: selectedLetter,
      status: "notAttempted",

    }

   

  })
  settestInfo(testInfo);
  setselectedParagraph(data);
  })
  
  

  
  
  

}, [])
// console.log(testInfo)
  
  
const handleuserInput= (inputValue) =>{
  
  const characters = inputValue.length
  const words = inputValue.split(" ").length
  const index = characters - 1;
  if(!timerstarted){
    startTimer(words);
  }

  if(index<0){
    settestInfo ([{
      testLetter: testInfo[0].testLetter,
      status: "notAttempted"

    }, ...testInfo.slice(1)])
    setCharacters(characters)
    setWords(words)
    return;

    
    



    
  }
  if(index>=selectedParagraph.length){
    setCharacters(characters)
    setWords(words)
    
    }
    // const testInfo = testInfo
    if(!(index === selectedParagraph.length-1)){
      testInfo[index+1].status="notAttempted"
    }
    const isCorrect = inputValue[index] === testInfo[index].testLetter;

    testInfo[index].status = isCorrect?"correct" :"incorrect";
    settestInfo(testInfo) 
    setCharacters(characters)
    setWords(words)
    // console.log(Words)

    




}



const startTimer = (Words) =>{
  settimerstarted(true)

const timer = setInterval(()=>{
  if(timeRemaining>0 ){
    const timeSpent =totaltime - timeRemaining
    // console.log(Words)
    const speed = timeSpent>0?(Words/timeSpent)*totaltime:0;
    // console.log(speed)
    
    
    settimeRemaining(timeRemaining -= 1);
    setWpm(parseInt(speed))
    // console.log(timeRemaining)
  }
  else{
    clearInterval(timer)
  }
},1000)

}
 const startAgain =()=>{ 
  fetchNewParagraph()

 }
 const fetchNewParagraph =()=>{
  fetch(url).then((resp) => resp.text()).then((data)=>{
    
    const paragraphArray=data.split("")
 const testInfo= paragraphArray.map((selectedLetter) =>{


    return{
      testLetter: selectedLetter,
      status: "notAttempted",

    }

   

  })
setselectedParagraph (" ")
settimerstarted(false)
settimeRemaining(totaltime)
setWords(0)
setCharacters(0)
setWpm(0);
settestInfo([])

  
settestInfo(testInfo);
setselectedParagraph(data);
  })


 }
 useEffect(()=>{
  fetchNewParagraph()

 },[])




  return (
    <div className="App">
     
    <Navbar/>
    <Landing/>
    <Challenge selectedParagraph={selectedParagraph}
    timerstarted={timerstarted}
    timeRemaining={timeRemaining}
    words={Words}
    characters={characters}
    wpm={Wpm}
    testInfo={testInfo}
    onInputChange={handleuserInput}
    startAgain={startAgain}

  />
    <Footer/>
    </div>
  );
}

export default App;
