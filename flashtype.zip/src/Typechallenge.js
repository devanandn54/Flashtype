import React from 'react'
import "./Typechallenge.css"

import ChallengeDetails from './ChallengeDetails'
import Challenge from './Challenge'
import TypingChallenge from './TypingChallenge'


const Typechallenge = ({selectedParagraph, timerstarted, timeRemaining, words, characters, wpm , testInfo , onInputChange}) => {
  return (
    <div className='typing-challenge-container'>
        <div className='details-container'>
            <ChallengeDetails CardName="Words" CardValue={words}/>
            <ChallengeDetails CardName="Characters" CardValue={characters}/>
            <ChallengeDetails CardName="Wpm" CardValue={wpm}/>
            
            <div className='typewriter-container'>
                <TypingChallenge selectedParagraph={selectedParagraph}
                timerstarted={timerstarted}
                timeRemaining={timeRemaining}
                testInfo ={testInfo}
                onInputChange={onInputChange}/>            
                </div>
        </div>
    </div>
  )
}

export default Typechallenge