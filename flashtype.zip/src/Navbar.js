import React from 'react'
import "./Navbar.css"

const Navbar = () => {
  return (
    <div className='nav-container'>
        <div className='nav-left'>
        <img className = 'logo' src="https://logos-world.net/wp-content/uploads/2021/08/Flash-Symbol.png" />
        <p className='logo-text'>flashtype</p>
        
        

        </div>
        <div className='nav-right'>
            <a  target='blank'
            className='nav-link' href="https://www.google.com/search?q=flash&rlz=1C1GCEU_enIN1030IN1030&source=lnms&tbm=isch&sa=X&ved=2ahUKEwjd0bXg07D-AhWDTWwGHeOpAG8Q_AUoAXoECAEQAw&biw=1366&bih=657&dpr=1#imgrc=qXA30RuWyCNMFM"
            rel='noreferrer'>follow</a>


           
            
        </div>
        
    </div>

  )
}

export default Navbar