import React from 'react'
import "./Footer.css";

const Footer = () => {
  return (
    <div className='footer-container'>
        <a href='https://www.google.com/search?q=flash&rlz=1C1GCEU_enIN1030IN1030&source=lnms&tbm=isch&sa=X&ved=2ahUKEwiZtM_36rL-AhXBcmwGHT-5C2gQ_AUoAXoECAEQAw&biw=1366&bih=657&dpr=1#imgrc=9jG9OwyvJAxiqM'
        className="footer-link"
        target='_blank'
        rel= 'noreferrer'
        >
          Watch  
            
        </a>
        
    </div>
  )
}

export default Footer