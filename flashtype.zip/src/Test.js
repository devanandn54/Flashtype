import React from 'react'
import Typechallenge from './Typechallenge'
import './Test.css'
import Tryagain from './TryAgain';
const Test = ({selectedParagraph, timerstarted, timeRemaining, words, characters, wpm ,testInfo, onInputChange, startAgain}) => {
    const timerRemaining =10;
  return (
    <div
    className='test-container'>
        {
          timeRemaining>0?( <div className='tying-challenge' >
          <Typechallenge selectedParagraph={selectedParagraph} timerstarted={timerstarted} timeRemaining={timeRemaining}
        words={words} characters={characters} wpm={wpm} testInfo={testInfo} onInputChange={onInputChange} 
        
          
          />
      </div>):(
      <div className='try-again'><Tryagain words={words}  characters={characters} wpm={wpm} startAgain={startAgain}/></div>)
        }
        

    </div>
  )
}

export default Test