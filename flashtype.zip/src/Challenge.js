import React from 'react'
import './Challenge.css'
import Test from './Test'

const Challenge = ({selectedParagraph, timerstarted, timeRemaining, words, characters, wpm, testInfo, onInputChange,startAgain}) => {
  return (
    <div className='challenge-section'>
        <h1  className='challenge-header'>
            Take a speed test now!

        </h1>
        <Test selectedParagraph={selectedParagraph} timerstarted={timerstarted} timeRemaining={timeRemaining}
        words={words} characters={characters} wpm={wpm} testInfo={testInfo} onInputChange={onInputChange}
        startAgain={startAgain}/>

    </div>
    
  )
}

export default Challenge