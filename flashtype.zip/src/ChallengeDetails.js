import React from 'react'
import "./ChallengeDetails.css"

const ChallengeDetails = ({CardName,CardValue}) => {
  return (
    <div className='details-card-container'

    >
        <div className='card-name'>
            {CardName}

        </div>
        <div className='card-value'>
            {CardValue}

        </div>
    </div>
  )
}

export default ChallengeDetails