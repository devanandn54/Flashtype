import React from "react";
import Typewriter from "typewriter-effect";
import "./Landing.css"

const Landing = () => {
  return (
    <div className="landing-container">
      <div className="landing-left">
        <h1 className="landing-header">Can u type..</h1>
         <div className="typewriter-container">
           <Typewriter 
          options={{
            strings: ["Hello", "World"],
            autoStart: true,
            loop: true,
          }}
        />
         </div>
        
      </div>
<div className='landing-right'>
    <img src='https://upload.wikimedia.org/wikipedia/en/b/b7/Flash_%28Barry_Allen%29.png' className="flash-image"
    alt="image"

    />
    

</div>
    </div>
  );
};

export default Landing;
